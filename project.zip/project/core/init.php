<?php
require_once "config/koneksi.php";
require_once "config/functions.php";
?>