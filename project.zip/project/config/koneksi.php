<?php
    $host     = 'localhost';
    $user     = 'newbiede_test'; // diisi dengan user database kalian biasanya
                        // defaultnya bernama root jika kita belum 
                        // merubahnya
    $password = 'Kusnari123';  //diisi dengan password database kalian biasanya
                     // defaultnya kosong
    $db       = 'newbiede_test'; //diisi dengan nama database kalian
     
    $link = mysqli_connect($host, $user, $password, $db) or die(mysqli_error());
?>